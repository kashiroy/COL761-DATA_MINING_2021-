#! /bin/bash
datafile=$2
support=$3
outputfile=$4
totalargs=$#

treetype=$(echo $1 | cut -d'-' -f 2)

if [ $totalargs = 4 ]
	then
		if [ $treetype = "prefixspan" ]
			then 
				./back_click $datafile
				./$treetype fin_res.dat $support $outputfile.txt
		else
			if [ $treetype = "apriori" ]
				then
					./$treetype $datafile $support $outputfile.txt
			else
				    if [ $treetype = "fpgrowth" ]
						then
							cd fpgrowth/fpgrowth/src	
							./$treetype -s$support ../../../$datafile  $outputfile.txt
				    else
						echo "Invalid tree "$treetype
				    fi
			fi
		fi	

else
	treetype=$(echo $datafile | cut -d'-' -f 2)
	if [ $treetype = "plot" ]
		then
			python3 plot.py $1
	else
		echo "Invalid argument "$2
	fi	
fi
		

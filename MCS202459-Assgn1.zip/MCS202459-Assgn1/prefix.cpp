#include<iostream>
#include<fstream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <set>
#include <unordered_set>
#include <map>
#include <algorithm>
#include <cmath>
using namespace std;


int min_sup;
int total;
vector<vector<int>> database;

set<vector<int>> c1;
map<vector<int>, map<int,int>> table1;

set<vector<int>> prev_L;

ofstream out;

unordered_map<string,int> mapper;
unordered_map<int,string> mapper_back;


void print_result(){

        for(auto y: prev_L){

            for(auto z: y)
            
                cout<<z<<" ";

            cout<<endl;
        }
}



void print_table(map<vector<int>, map<int,int>> table)
{
    for(auto it: table)
    {
    
        cout<<"<";
       for(auto x:it.first)
       {
           cout<< x <<",";
       }
       cout<<">  :  ";
       for(auto it1:it.second)
       {
     
         cout<<it1.first<< ":"<<it1.second <<" ";

       }
    cout<<endl;
    }

}


void print_CL(vector<vector<int>> curr_L){

    for(auto it:curr_L)
    {

        for(auto it1:it)
        {
            cout<<it1<<" ";
        }
        cout<<endl;
    }

}


void write_output(set<vector<int>> l)
{


    set<vector<string>> result;

    for(auto x : l)
    {

            vector<string> temp;

            for(auto y: x)
            {
                temp.push_back(mapper_back[y]);
            }

            result.insert(temp);

    }


    for(auto x : result)
    {

            for(auto z: x)
            {
                out<<z;
                out<<" ";
            }
            out<<endl;
    }


}


void initial(){

    //C1 and table creation 

    for(int i=0;i<database.size();i++){
        for(int j=0;j<database[i].size();j++){
            
            if(c1.find({database[i][j]})==c1.end())
                { 
                    c1.insert({database[i][j]});
                
                    }
            
            if( table1[{database[i][j]}].find({i})==table1[{database[i][j]}].end())
                table1[{database[i][j]}][i]=j;

        }
    }

    //pruning

    set<vector<int>> l1;
    l1=c1;

    for(auto it:c1){

        if( table1[it].size() < min_sup)
        {
            l1.erase(it);
            table1.erase(it);
        }
    }

    write_output(l1);
    prev_L = l1;

}


int main(int argc, char** argv){

    int min_perc =stoi(argv[2]);
    string input_name = argv[1];
    string output_name = argv[3];

    min_sup=0;
    total=0;

    fstream file;
    file.open(input_name, ios::in);

    out.open(output_name, ios::out);


    string s;

    int counter=1;
        
    while(getline(file,s)){

        total++;  
        istringstream split(s);
        vector<int> temp;
        string token;

        while (std::getline(split, token, ';')) {

            if (!token.empty()){

                if(mapper.find(token)==mapper.end()){
                    mapper[token]=counter;
                    mapper_back[counter] = token;
                    counter++;
                }

                temp.push_back(mapper[token]);
            }
        }

        database.push_back(temp);
    }
    

    min_sup = ceil((min_perc/100.0)*total);

    initial();

    //one length process ends here

    while(prev_L.size()!=0){

        set<vector<int>> C = prev_L;

        set<vector<int>> curr_L;

        for(auto v : C){

            unordered_map<int,int> count_elem;

            for(auto pair : table1[v]){

                unordered_set<int> presence; 
                int row_no=pair.first;
                int col_no=pair.second+1;

                for(int i=col_no;i<database[row_no].size();i++){
                
                    if(presence.find(database[row_no][i])==presence.end()){
                        presence.insert(database[row_no][i]);
                        count_elem[database[row_no][i]]++;
                    }


                }

            }

            vector<int> temp;

            //next item of subsequence decided 
            for(auto x: count_elem){

                if(x.second>=min_sup)
                    temp.push_back(x.first);

            }


            //+1 lenth subsequence created
            for(auto y: temp){

                vector<int> t = v;
                t.push_back(y);

                curr_L.insert(t);
            }

        }

    
        //table2 created
        map<vector<int>, map<int,int>> table2;

        for(auto v: curr_L){

            vector<int> t = v;

            int last = t.back();

            t.pop_back();

            vector<int> rem = t; 

            for(auto x :table1[rem]){

                for(int j = x.second+1; j<database[x.first].size(); j++){

                    if(database[x.first][j]==last){

                        table2[v][x.first] = j;
                        break;
                        
                    }

                }

            }

        }

        write_output(curr_L);
        //data updated for next step
        table1 = table2;
        prev_L = curr_L;

    }

    out.close();

    return 0;
}
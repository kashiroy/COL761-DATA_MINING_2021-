+++++++++++++++++++++++++++++Assignment 1: Apriori and Prefix_Span++++++++++++++++++++++++++++++++++++++
#Language used :: 
->C++
Files::
->compile.sh
->install.sh
->MCS202459.sh
->apriori.cpp
->back_click.cpp
->prefix.cpp
->plot.py

#############################################Apriori########################################################

->Created initial_C_creation function for creating initial 'C' and 'L' table, count frequency and prune on the basis of support computed 
in this function for initial 'C' table. 
->To compute the frequency and prune on the basis of frequency, created compute_and_prune_frquency function and to prune the 
subset created subset_pruning function.
->On high support threshold value we are getting output on decent time but as we decreases the support threshold, number of frequent
items increases and computation time also increases.
->By subset pruning process tried to reduce database scan but support will be check for each item set and will take time.
-> according to observation we are getting output of apriori, on support threshold 90%, 50% and 25% but on 10% and 5%
support threshold timeout means more than an hour taken.

###############################################Analysis#########################################################

->Analysis done on fp tree and apriori procedure with threshold value taken as 5%,10%,25%,50% and 90%.
-> Observed that for higher threshold value, frequent pattern tree and apriori takes almost similar time to complete the process.
-> But when we decrease the threshold value, apriori takes more time in comparision to frequent pattern tree and performance 
of apriori becomes lower.

############################################Prefix__Span##############################################################

*#*#*Preprocessing Procedure::

Took Paths_finished.dat file from http://snap.stanford.edu/data/wikispeedia.html and which has column wise data and description
about data at start of the data file.We need to  extract the column 4 from the  database which denotes the visited paths and it 
contians back click(<) also. To extract the specific column and to remove the back click,created a cpp program with the name
back_click.cpp steps performed  as follows:

*step1: open file 
*step2: Skipping the data description comment by checking the condition which line has starting character as '#'.
*step3: Now, read line by line and select column 4 from each line which contains paths.
*step4: After select paths column, split the each item on the basis of ';' as a separator and store it into tokens vector 
which contains string.
*step5: Now, process the each vector, and if any back click(<) occurs then replace this back click with the previous of last
string(item).
*step6: Each item separate with ';' in data now and all back click replaced with an appropriate item.
*step7: Done preprocessing and stored the preprocessed data into a new file named as "fin_res.dat"
*step8: Used this preprocessed data as an input in prefix.cpp program for running of prefix span algorithm.

++++++Team Member+++++++++++++
Kashi Roy (2020MCS2459)
Deepak Kunwar (2020MCS2455)
Purushottam Bairwa (2020MCS2464)







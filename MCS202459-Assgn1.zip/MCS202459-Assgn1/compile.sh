#!/bin/bash
g++ -O3 apriori.cpp -o apriori -std=c++11
g++ -O3 back_click.cpp -o back_click -std=c++11
g++ -O3 prefix.cpp -o prefixspan -std=c++11
cd fpgrowth/fpgrowth/src
make all
cd ..
cd ..
cd ..

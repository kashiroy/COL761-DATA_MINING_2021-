#git clone https://github.com/kashiroy/COL761-DATA_MINING_2021-.git
module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
module load compiler/gcc/7.1.0/compilervars
module load compiler/python/3.6.0/ucs4/gnu/447
module load apps/anaconda/3
module list

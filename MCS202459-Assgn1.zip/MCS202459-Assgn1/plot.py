import time
import os
from matplotlib import pyplot as plt
import sys

script = "sh MCS202459.sh"
outputfile = "filename"
input_file = sys.argv[1]
supports = [90, 50, 25, 10, 5]

if __name__ == '__main__':
    apriori = []
    fptree = []

    for support in supports:
        start = time.time()
        os.system(script+" -apriori"+" "+input_file+" "+str(support)+" "+outputfile)
        end = time.time()
        apriori.append(end - start)
    
    for support in supports:
        start = time.time()
        os.system(script+" -fpgrowth"+" "+input_file+" "+str(support)+" "+outputfile)
        end = time.time()
        fptree.append(end - start)

plt.figure()
plt.plot(supports, apriori, label='Apriori')
plt.plot(supports, fptree, label='FP-tree')
plt.title('Running time Comparasion')
plt.xlabel('Support threshold')
plt.ylabel('Running Times(s)')
plt.legend()
plt.savefig("Plot.png")
    

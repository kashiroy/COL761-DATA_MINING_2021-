#include<iostream>
#include<fstream>
#include <sstream>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <cmath>

using namespace std;


//with map as key as index_no


string filename;
int total;
int support;
int length=0;


// map<int,int> C_dict;

// set<set<int>> C;

// set<set<int>> L;

// set<set<int>> L_helper;

// map<int, set<set<int>>> result;

fstream file;

ofstream out;

// void print_C_dict(){

//     for(auto x: C_dict){

//         set<int> t = x.first;
//         int freq = x.second;

//         for(auto y: t){

//             cout<<y<<" ";
//         } 

//         cout<<" : "<<freq<<endl;
//     }

// }

// void print_L(){

//         for(auto x: L){

//         for(auto y: x){

//             cout<<y<<" ";
//         } 
//         cout<<endl;
//     }

// }




void create_C(set<set<int>> &C, map<int,int> &C_dict, set<set<int>> &L){

    C.clear();
    C_dict.clear();

    for(auto it = L.begin(); it!= L.end(); it++){

        auto it2 = it;
        it2++;

        for(; it2!=L.end(); it2++){

            set<int> s1 = *it;
            set<int> s2 = *it2;

            int num1= *s1.rbegin();
            int num2= *s2.rbegin();

            s1.erase(num1);
            s2.erase(num2);

            if(s1==s2){

                s1.insert(num1);
                s1.insert(num2);

                C.insert(s1);
            }
            else
                break;
 
        }

    }

}



void initial_C_creation(int &percentage, map<int,int> &C_dict, set<set<int>> &L_helper){

    string s;

    file.open(filename, ios::in);


    while(getline(file,s)){

        total++;

        stringstream split(s);
        string temp;
        int x;

        while(split>>temp){
            x = stoi(temp);             

            //set<int> t;
            //t.insert(x);

            C_dict[x]++;
        }
    }

    file.close();

    support = ceil((percentage/100.0)*total);

    L_helper.clear();

    set<int> t;

    for(auto x: C_dict){

        if(x.second>=support){
            t.insert(x.first);
            L_helper.insert(t);
            t.clear();
        }
    }

}


void compute_and_prune_frequency(set<set<int>> &C, map<int,int> &C_dict, set<set<int>> &L_helper){

    vector<set<int>> C_vector {C.begin(), C.end()};

    string s;

    file.open(filename, ios::in);

    while(getline(file,s)){

        stringstream split(s);
        string temp;
        int x;

        set<int> row;

        while(split>>temp){
            x = stoi(temp);             
            row.insert(x);
        }


        for(int i =0; i<C_vector.size(); i++){

            if(includes(row.begin(), row.end(), C_vector[i].begin(), C_vector[i].end()))
                C_dict[i]++;
        }

    }

    
    file.close();

    L_helper.clear();

    for(auto x: C_dict){

        if(x.second>=support)
            L_helper.insert(C_vector[x.first]);

    }
    
}


void subset_pruning(set<set<int>> &C, set<set<int>> &L){

    set<set<int>> help=C;

    for(auto x: help){

        set<int> temp;

        int flag=1;

        for(auto it = x.begin(); it != x.end(); it++){

            temp = x;

            int num = *it;

            temp.erase(num);

            if(L.find(temp)==L.end()){
                flag=0;
                break;
            }

        }

        if(flag==0)
            C.erase(x);

    }

}


void write_output(map<int, set<set<int>>> &result){

    for(auto k: result){

        for(auto x : k.second){

            set<string> temp;

            for(auto y: x){
                temp.insert(to_string(y));
            }

            //sort(temp.begin(), temp.end());

            for(auto z: temp){

                out<<z;
                out<<" ";
            }

            out<<endl;
        }
    }
}



int main(int argc, char** argv){

    int percentage = stoi(argv[2]);

    string dataset = argv[1];

    string output_name = argv[3];


// int main(){

//     int percentage = 60;

//     string dataset = "sample.dat";

//     string output_name = "filename.txt";


    map<int,int> C_dict;

    set<set<int>> C;

    set<set<int>> L;

    set<set<int>> L_helper;

    map<int, set<set<int>>> result;

    out.open(output_name, ios::out);

    filename = dataset;

    initial_C_creation(percentage,C_dict,L_helper);


    //frequency_pruning();

    L = L_helper;

    result[length] = L;
    length++;

    while(true){

        create_C(C, C_dict, L);
        
        subset_pruning(C, L);

        //compute_frequency();

        compute_and_prune_frequency(C, C_dict, L_helper);

        //frequency_pruning();

        if(L_helper.empty())
            break;

        L = L_helper;

        result[length] = L;

        length++;

    }

    write_output(result);
 
    out.close();
}








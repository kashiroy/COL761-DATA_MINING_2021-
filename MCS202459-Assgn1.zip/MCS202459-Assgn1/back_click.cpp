#include<iostream>
#include<fstream>
#include<sstream>
#include<vector>
#include<unordered_map>

using namespace std;

ofstream myfile ("fin_res.dat");

void creator(vector<string> tokens)
{

    unordered_map<string, string> supporter;

    vector<string> result;

    for(int i=0;i<tokens.size();i++){

        if(tokens[i]=="<"){
            string temp=result.back();
            result.push_back(supporter[temp]);
        }
        else
        {
            if(i!=0){
                supporter[tokens[i]]=result.back();
            }
            result.push_back(tokens[i]);
        }
    }

    string finall="";

    for(int i=0;i<result.size();i++){
        finall+=result[i];
        if(i==result.size()-1)
        {//cout<<finall<<endl;
        }
        else{
        finall+=";";
        }
    }
    myfile<<finall<<endl;


}


int main(int argc, char** argv){

    fstream file;
    file.open(argv[1], ios::in);
    string s;

    
vector<string> tokens;
    while(getline(file,s)){

        if(s[0]=='#')
            continue;

        if(s.size()==0)
            continue;

        istringstream split(s);
        
        string token;

         int count=0;
       while (std::getline(split, token, '\t')) {

          
    if (!token.empty())

        count++;

        if(count==4){

            istringstream split2(token);
        
            string tok;

            while (std::getline(split2, tok, ';')) {
          
                if (!tok.empty()){

                    tokens.push_back(tok);
                }

            }

            creator(tokens);
            tokens.clear();

            }
        }
    }

return 0;
}
#! /bin/bash
inputfile=$1
plot_name=$2
cd Q1
chmod +x run.sh
chmod +x compile.sh
./compile.sh ../$1

python3 graph.py $2


		

+++++++++++++++++++++++++++++Assignment 2: Q1.frequent subgraph mining tools++++++++++++++++++++++++++++++++++++++

#Language used :: 
->C++,Python,Bash
Files::
->install.sh

Q1:Code and Script
->Q1.sh
->compile.sh
->run.sh
->pre_fsg.cpp
->pre_gs_gaston.cpp
->graph.py

Q2:Code and Script
->Q2.sh
->pca.py
->graph2.py
->combine.py


Execution Steps:
1:install.sh (It will clone git hub repository and load all the required modules.)
2:Q1.sh <data_file> <plot_name> (It will generate Plot the running times for gSpan, FSG (also known as PAFI) and Gaston.)
3:Q2.sh <data_file> <plot_name> (It will generate Plot for 100 random points as query and plot the average running time of 5-NN query with standard 				 deviation as error bars for KD-tree, M-tree and Sequential scan against dimension.)


Reference:
Mtree Library:https://github.com/tburette/mtree

++++++Team Member+++++++++++++
Kashi Roy (2020MCS2459)
Deepak Kunwar (2020MCS2455)
Purushottam Bairwa (2020MCS2464)

from sklearn.neighbors import KDTree
import numpy as np
import heapq
import math
import time
import mtree
import sys

#start = time.time()



def comb(input_file):
    vector_list = []
    file = open(input_file, "r")   
    data= []

    dimensions = 0

    for row in file:
        temp = list(row.split(" "))
        inner = [float(value) for value in temp]
        dimensions = len(inner)
        data.append(inner)

    #print(data)

    #end = time.time()

    #print(end-start)


    r_obj = np.random.RandomState(0)
    query_data = r_obj.random_sample((10, dimensions))



    # ------------------kd tree working-----------------

    kd_tree = KDTree(data, leaf_size=2) 

    kd_timing = []

    for q in query_data:

        start = time.time()

        distances, indices = kd_tree.query([q], k=5)   

        end = time.time()

        kd_timing.append(end-start)

        #print(indices)
        #print(distances)

    print(kd_timing)
    vector_list.append(kd_timing)


    # ------------------linear approach working-----------------


    linear_timing = []

    K=5

    for q in query_data:

        start = time.time()

        heap = []
        index =0

        for row in data:

            sum = 0
            for i in range(0,dimensions):
                sum += (row[i]-q[i])**2

            dist= math.sqrt(sum)

            heapq.heappush(heap,(-1*dist,index))

            if(len(heap)==K+1):
                heapq.heappop(heap)

            index = index+1


        for i in range(0,len(heap)):
            element = heapq.heappop(heap)
            #print(-1*element[0], end = " , ")
            #print(data[element[1]])

        end = time.time()

        linear_timing.append(end-start)


    print(linear_timing)
    vector_list.append(linear_timing)



    # ------------------m tree working-----------------

    def distance_function(x, y):     

        n = len(x)
        sum=0
        for i in range(0,n):
            sum += (x[i]-y[i])**2

        return math.sqrt(sum)
    


    m_tree = mtree.MTree(distance_function, max_node_size=4)

    m_timing = []

    m_tree.add_all(data)

    for q in query_data:

        start = time.time()

        result = m_tree.search(q,5)

        end = time.time()

        #print(list(result))

        m_timing.append(end-start)


    print(m_timing)
    vector_list.append(m_timing)
    return vector_list



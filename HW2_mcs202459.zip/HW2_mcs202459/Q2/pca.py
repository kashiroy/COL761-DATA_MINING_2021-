import sys
import csv
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn import decomposition 

input_data=sys.argv[1]
df= pd.read_csv(input_data, header = None, delim_whitespace=True, error_bad_lines=False)


scaler_data = StandardScaler().fit_transform(df)
# print(scaler_data.shape)

for i in [2,4,10,20]:
    pca = decomposition.PCA()
    pca.n_components=i
    pca_data = pca.fit_transform(scaler_data)
    reduced = pd.DataFrame(pca_data)
    reduced.to_csv( str(i)+'d.dat', header=False, sep=' ', index=False) 
    #   reduced.to_csv( str(i)+'d.dat') 
    #   print(reduced.head())
    # print(pca_data.shape)i

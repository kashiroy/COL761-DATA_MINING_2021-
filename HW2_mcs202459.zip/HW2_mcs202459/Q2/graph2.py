import time
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sys

#sys.path.insert(1, '/home/kashi/q2/mtree_master')
  
from combine import comb
 
plot_name = sys.argv[1]

dimension_file = ["2d","4d","10d","20d"]

map ={}
if __name__ == '__main__':
    for d in dimension_file:
        vector_list = []
        input = d+".dat"
        vector_list=comb(input)
        map[d] = vector_list

dim = []
mean =[]
std = []
algo = []


for key in map:
    
    dim.append(key)
    dim.append(key)
    dim.append(key)
    df = pd.DataFrame.from_records(map[key])
    df = df.transpose()
    # print(df.head())
    df.columns = ["KD-Tree", "Linear", "M-Tree"]
    
    for ids in ["KD-Tree", "Linear", "M-Tree"]:
        # print(ids)
        mean.append(df[ids].mean())
        std.append(df[ids].std())
        algo.append(ids)
    # print("std \n",df.std())
    # print("mean \n",df.mean())      
    
df1 = pd.DataFrame({'Dimensions':dim,'mean': mean,'algo': algo,'std': std})

# print(df1)
fig, ax = plt.subplots()
 
for key, group in df1.groupby('algo'):
    group.plot('Dimensions', 'mean', yerr='std',
               label=key, ax=ax)
 
plt.show()
plt.savefig(plot_name+".png")

    

from sklearn.neighbors import KDTree
import numpy as np
import heapq
import math
import time
import mtree
import sys

data = np.array([[1,2,3,4],[5,6,7,8]])
kd_tree = KDTree(data, leaf_size=2) 
print(data)
print("executed")
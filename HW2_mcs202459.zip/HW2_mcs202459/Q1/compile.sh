#!/bin/bash
inputfile=$1
g++ -O3 pre_gs_gaston.cpp -o gs_gaston -std=c++11
g++ -O3 pre_fsg.cpp -o clean_fsg -std=c++11
./gs_gaston $inputfile
./clean_fsg $inputfile

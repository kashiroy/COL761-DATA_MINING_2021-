#include<iostream>
#include<fstream>
using namespace std;

int main(int argc, char** argv)
{

//for write new clean data in this file 
ofstream outdata;
outdata.open("data_gs_gaston.dat", ios::out);

//for taking input
fstream file;
file.open(argv[1], ios::in);
string s;

int g_id=0;
string token;
//read the input
while(getline(file,s)){
          
       if(s[0]==' ')
       continue;
       else if(s[0]=='#')
       {
           string helper= "t ";
           helper = helper+"# "+ to_string(g_id++);
           //helper ko output file m daalna h yha
           outdata<<helper<<endl;
           string t1;
           getline(file,t1);
           int v_loop=stoi(t1);
           int i=0;
           string t2;
           while(i<v_loop && getline(file,t2) )
           {
               string temp= "v "+to_string(i)+" "+ to_string(t2[0]-'A');
               outdata<<temp<<endl;
               i++;
           }
           string t3;
           getline(file,t3);
           int e_loop=stoi(t3);
           int j=0;
           string t4;
           while(j<e_loop && getline(file,t4))
           {
            string temp="e "+t4;
            outdata<<temp<<endl;
            j++;
           }
       } 

    }
    ofstream kashi;
    kashi.open("total_count.txt", ios::out);
    kashi<<g_id;
}
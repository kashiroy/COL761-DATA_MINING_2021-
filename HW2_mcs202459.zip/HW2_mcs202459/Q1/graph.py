import time
import os
from matplotlib import pyplot as plt
import sys

script = "sh run.sh"

plot_name = sys.argv[1]
supports = [95.0,50.0,25.0,10.0]

if __name__ == '__main__':
    fsg = []
    gSpan_64 = []
    gaston = []

    for support in supports:
        start = time.time()
        os.system(script+" fsg"+" "+str(support))
        end = time.time()
        fsg.append(end - start)
    
    for support in supports:
        start = time.time()
        tmp = (support/100)
        print(tmp)
        os.system(script+" gSpan-64"+" "+str(tmp))
        end = time.time()
        gSpan_64.append(end - start)
    

    file1 = open("total_count.txt","r")
    total = int(file1.read())

    for support in supports:
        start = time.time()
        tmp = (support*total)/100
        print(tmp)
        os.system(script+" gaston"+" "+str(tmp))
        end = time.time()
        gaston.append(end - start)

plt.figure()
plt.plot(supports, fsg, label='fsg')
plt.plot(supports, gSpan_64, label='gSpan-64')
plt.plot(supports, gaston, label='gaston')
plt.title('Running time Comparasion')
plt.xlabel('Support threshold')
plt.ylabel('Running Times(s)')
plt.legend()
plt.savefig(plot_name+".png")
    

#! /bin/bash
# inputfile=$2
support=$2
treetype=$(echo $1)


if [ $treetype = "fsg" ]
    then 
        cd pafi-1.0.1/Linux
        chmod +x ./$treetype 
        ./$treetype -s $support ../../data_fsg.dat
else
    if [ $treetype = "gSpan-64" ]
        then
            cd gSpan6
            chmod +x ./$treetype
              # ./$treetype -f $inputfile -s $support 
            ./$treetype -f ../data_gs_gaston.dat -s $support
    else
            if [ $treetype = "gaston" ]
                then
                    cd gaston-1.1
                    make clean
                    make
                    chmod +x ./gaston	
                    ./$treetype $support ../data_gs_gaston.dat 
            else
                echo "Invalid tree "$treetype
            fi
    fi
fi		
echo "Run "
		

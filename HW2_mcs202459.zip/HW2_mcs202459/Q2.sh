#! /bin/bash
inputfile=$1
plot_name=$2

cd Q2
#module load compiler/python/3.6.0/ucs4/gnu/447 
#module load pythonpackages/3.6.0/ucs4/gnu/447/pip/9.0.1/gnu
#module load pythonpackages/3.6.0/ucs4/gnu/447/setuptools/34.3.2/gnu
#module load pythonpackages/3.6.0/ucs4/gnu/447/wheel/0.30.0a0/gnu
#module load apps/pythonpackages/3.6.0/tensorflow/1.9.0/gpu
#module load apps/pythonpackages/3.6.0/keras/2.2.2/gpu
#module load apps/pythonpackages/3.6.0/pytorch/0.4.1/gpu
#module load apps/pythonpackages/3.6.0/tensorflow/1.9.0/gpu
#module load apps/pythonpackages/3.6.0/torchvision/0.2.1/gpu
#module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
#module load apps/anaconda/3

python3 pca.py ../$inputfile
python3 graph2.py $plot_name
